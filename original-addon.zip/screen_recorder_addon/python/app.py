"""
app.py — واجهة تطبيق تسجيل الشاشة (Toga)

هذا الملف مثال متكامل، ادمج محتواه مع src/helloworld/app.py
الموجود في مشروعك (احتفظ بالاسم helloworld إن لم تغيّره).

يعمل فقط على أندرويد (كود rubicon-java يُتجاهَل/يفشل على ويندوز،
لذلك تم عزله بشرط منصة).
"""

import sys
import asyncio

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW

IS_ANDROID = sys.platform == "android"

if IS_ANDROID:
    from java import jclass


class ScreenRecorderApp(toga.App):

    def startup(self):
        self.status_label = toga.Label(
            "جاهز للتسجيل", style=Pack(padding=10, text_align="center")
        )
        self.record_button = toga.Button(
            "بدء التسجيل",
            on_press=self.toggle_recording,
            style=Pack(padding=10),
        )

        box = toga.Box(
            children=[self.status_label, self.record_button],
            style=Pack(direction=COLUMN, padding=20, alignment="center"),
        )

        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = box
        self.main_window.show()

        self.is_recording = False

    def toggle_recording(self, widget):
        if not self.is_recording:
            self.main_window.add_background_task(self.start_recording_flow)
        else:
            self.stop_recording()

    async def start_recording_flow(self, app, **kwargs):
        if not IS_ANDROID:
            self.status_label.text = "التسجيل متاح فقط على أندرويد"
            return

        # تحقق من صلاحية النافذة العائمة أولاً (تحتاج موافقة يدوية من المستخدم)
        if not self.has_overlay_permission():
            self.status_label.text = "امنح صلاحية 'العرض فوق التطبيقات' ثم أعد المحاولة"
            self.request_overlay_permission()
            return

        # اطلب إذن تسجيل الشاشة (MediaProjection)
        Bridge = jclass("com.example.helloworld.ScreenRecordBridge")  # ⚠️ عدّل الحزمة
        Bridge.resultReceived = False

        activity = self._impl.native  # الـ Activity الحالية على أندرويد
        activity.requestScreenCapturePermission()

        self.status_label.text = "بانتظار موافقتك على تسجيل الشاشة..."

        # انتظار (polling) حتى يصل رد المستخدم من onActivityResult في Java
        for _ in range(100):  # حد أقصى ~20 ثانية
            if Bridge.resultReceived:
                break
            await asyncio.sleep(0.2)

        if not Bridge.resultReceived or not Bridge.permissionGranted:
            self.status_label.text = "تم رفض إذن تسجيل الشاشة"
            return

        # ابدأ خدمة النافذة العائمة (اختياري لكنه مفيد للتحكم بدون فتح التطبيق)
        OverlayService = jclass("com.example.helloworld.OverlayService")
        overlay_intent = jclass("android.content.Intent")(activity, OverlayService)
        activity.startService(overlay_intent)

        self.is_recording = True
        self.record_button.text = "إيقاف التسجيل"
        self.status_label.text = "جاري التسجيل الآن..."

    def stop_recording(self):
        if not IS_ANDROID:
            return

        activity = self._impl.native
        ScreenRecordService = jclass("com.example.helloworld.ScreenRecordService")
        Intent = jclass("android.content.Intent")

        stop_intent = Intent(activity, ScreenRecordService)
        stop_intent.setAction("STOP")
        activity.startService(stop_intent)

        self.is_recording = False
        self.record_button.text = "بدء التسجيل"
        self.status_label.text = "تم إيقاف التسجيل. الملف في: Movies/ScreenRecords"

    # ---------- صلاحية النافذة العائمة ----------

    def has_overlay_permission(self):
        Settings = jclass("android.provider.Settings")
        return bool(Settings.canDrawOverlays(self._impl.native))

    def request_overlay_permission(self):
        Intent = jclass("android.content.Intent")
        Settings = jclass("android.provider.Settings")
        Uri = jclass("android.net.Uri")

        activity = self._impl.native
        package_name = activity.getPackageName()

        intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + package_name),
        )
        activity.startActivity(intent)


def main():
    return ScreenRecorderApp("تسجيل الشاشة", "com.example.helloworld")


if __name__ == "__main__":
    main().main_loop()
