package com.example.helloworld;  // ⚠️ غيّر هذا ليطابق حزمة تطبيقك الفعلية
// اسم الحزمة الصحيح تجده في: android/app/build.gradle -> applicationId "..."
// أو في مسار المجلد الحالي لـ MainActivity الأصلية داخل مشروعك.

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

/**
 * نسخة معدّلة من MainActivity التي يولّدها Briefcase.
 * الإضافة الوحيدة: طلب إذن MediaProjection واستقبال نتيجته،
 * ثم تمريرها إلى ScreenRecordService.
 *
 * إن كانت MainActivity الأصلية في مشروعك تحتوي على كود إضافي
 * (مثلاً دوال أخرى)، انسخ فقط الدوال أدناه إليها بدل استبدال الملف كاملاً.
 */
public class MainActivity extends org.beeware.android.MainActivity {

    public static final int REQUEST_CODE_SCREEN_CAPTURE = 1001;

    /** يُستدعى من بايثون عبر rubicon-java لطلب إذن تسجيل الشاشة */
    public void requestScreenCapturePermission() {
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent captureIntent = mpm.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQUEST_CODE_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SCREEN_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                // مرّر النتيجة مباشرة لخدمة التسجيل لتبدأ الالتقاط الفعلي
                Intent serviceIntent = new Intent(this, ScreenRecordService.class);
                serviceIntent.putExtra("resultCode", resultCode);
                serviceIntent.putExtra("data", data);
                startForegroundService(serviceIntent);

                // علم بسيط يقرأه بايثون (polling) لمعرفة أن الإذن مُنح
                ScreenRecordBridge.permissionGranted = true;
            } else {
                ScreenRecordBridge.permissionGranted = false;
            }
            ScreenRecordBridge.resultReceived = true;
        }
    }
}
