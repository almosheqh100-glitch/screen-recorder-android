package com.example.helloworld;  // ⚠️ غيّره ليطابق حزمة تطبيقك

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * خدمة أمامية (Foreground Service) تقوم بالتسجيل الفعلي للشاشة
 * باستخدام MediaProjection + VirtualDisplay + MediaRecorder.
 *
 * ملاحظة عن الصوت:
 * - تسجيل صوت الميكروفون: مدعوم مباشرة عبر MediaRecorder (AudioSource.MIC).
 * - تسجيل صوت النظام (system/internal audio): يتطلب AudioPlaybackCaptureConfiguration
 *   (Android 10 فأعلى)، وهو أكثر تعقيدًا (يحتاج AudioRecord منفصل + دمج الصوتين).
 *   تركته هنا كنقطة توسعة لاحقة (TODO) حتى لا يتضخم الكود الأساسي.
 */
public class ScreenRecordService extends Service {

    private static final String CHANNEL_ID = "screen_record_channel";
    private static final int NOTIFICATION_ID = 42;

    private MediaProjection mediaProjection;
    private MediaRecorder mediaRecorder;
    private VirtualDisplay virtualDisplay;

    private int screenWidth, screenHeight, screenDensity;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());

        if (intent != null && intent.hasExtra("resultCode")) {
            int resultCode = intent.getIntExtra("resultCode", -1);
            Intent data = intent.getParcelableExtra("data");

            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = mpm.getMediaProjection(resultCode, data);

            try {
                startRecording();
                ScreenRecordBridge.isRecording = true;
            } catch (IOException e) {
                ScreenRecordBridge.lastError = e.getMessage();
                stopSelf();
            }
        } else if (intent != null && "STOP".equals(intent.getAction())) {
            stopRecording();
            stopSelf();
        }

        return START_NOT_STICKY;
    }

    private void startRecording() throws IOException {
        String outputPath = getOutputFilePath();

        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setVideoSize(screenWidth, screenHeight);
        mediaRecorder.setVideoEncodingBitRate(8 * 1024 * 1024);
        mediaRecorder.setVideoFrameRate(30);
        mediaRecorder.setOutputFile(outputPath);
        mediaRecorder.prepare();

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenRecord",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mediaRecorder.getSurface(), null, null
        );

        mediaRecorder.start();
        ScreenRecordBridge.lastOutputPath = outputPath;
    }

    private void stopRecording() {
        try {
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
            }
        } catch (Exception e) {
            ScreenRecordBridge.lastError = e.getMessage();
        }

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        ScreenRecordBridge.isRecording = false;
    }

    private String getOutputFilePath() {
        File dir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ScreenRecords"
        );
        if (!dir.exists()) dir.mkdirs();

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return new File(dir, "record_" + timestamp + ".mp4").getAbsolutePath();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "تسجيل الشاشة", NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("جاري تسجيل الشاشة")
                .setContentText("اضغط لإيقاف التسجيل من التطبيق")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        stopRecording();
        super.onDestroy();
    }
}
