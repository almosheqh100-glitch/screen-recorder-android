package com.example.helloworld;  // ⚠️ غيّره ليطابق حزمة تطبيقك

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

/**
 * نافذة عائمة صغيرة (زر إيقاف تسجيل) تظهر فوق كل التطبيقات أثناء التسجيل.
 * تتطلب صلاحية "العرض فوق التطبيقات الأخرى" (SYSTEM_ALERT_WINDOW)
 * والتي يجب أن يمنحها المستخدم يدويًا من الإعدادات (لا يمكن طلبها
 * تلقائيًا مثل الصلاحيات العادية) عبر:
 *
 *   Settings.ACTION_MANAGE_OVERLAY_PERMISSION
 *
 * استدعِ هذا من بايثون قبل بدء التسجيل إن لم تكن الصلاحية ممنوحة بعد.
 */
public class OverlayService extends Service {

    private WindowManager windowManager;
    private LinearLayout overlayView;

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        Button stopButton = new Button(this);
        stopButton.setText("إيقاف التسجيل");
        stopButton.setBackgroundColor(Color.parseColor("#CC1E1E1E"));
        stopButton.setTextColor(Color.WHITE);

        overlayView = new LinearLayout(this);
        overlayView.addView(stopButton);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 16;
        params.y = 100;

        windowManager.addView(overlayView, params);

        stopButton.setOnClickListener(v -> {
            Intent stopIntent = new Intent(this, ScreenRecordService.class);
            stopIntent.setAction("STOP");
            startService(stopIntent);
            stopSelf();
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
        }
        super.onDestroy();
    }
}
