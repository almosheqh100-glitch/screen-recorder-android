package com.example.helloworld;  // ⚠️ غيّره ليطابق حزمة تطبيقك

/**
 * كلاس بسيط بحقول static فقط، يستخدمه Java وبايثون معًا كـ "صندوق بريد"
 * لتبادل الحالة، لأن استدعاء الدوال بين بايثون وJava عبر rubicon-java
 * سهل، لكن الـ callbacks العكسية (Java -> Python) أصعب.
 * لذلك نعتمد على Polling بسيط من بايثون (كل 200-300ms) بعد بدء الطلب.
 */
public class ScreenRecordBridge {
    public static volatile boolean resultReceived = false;
    public static volatile boolean permissionGranted = false;
    public static volatile boolean isRecording = false;
    public static volatile String lastOutputPath = "";
    public static volatile String lastError = "";
}
